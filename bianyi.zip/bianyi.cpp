#include <iostream>
#include <fstream>
#include <unordered_map>
#include <string>
#include <cctype>
#include <vector>
using namespace std;

string currentToken;
string currentValue;
ifstream inFile;
ofstream outFile;
bool enableOutput = true;
vector<pair<string, string>> tokenBuffer;
int bufferIndex = -1;

unordered_map<string, string> keywords;
unordered_map<string, string> symbols;

void initHashTables() {
    keywords["const"] = "CONSTTK";
    keywords["int"] = "INTTK";
    keywords["char"] = "CHARTK";
    keywords["void"] = "VOIDTK";
    keywords["main"] = "MAINTK";
    keywords["if"] = "IFTK";
    keywords["else"] = "ELSETK";
    keywords["while"] = "WHILETK";
    keywords["break"] = "BREAKTK";
    keywords["continue"] = "CONTINUETK";
    keywords["return"] = "RETURNTK";
    keywords["printf"] = "PRINTFTK";
    
    symbols["+"] = "PLUS";
    symbols["-"] = "MINU";
    symbols["*"] = "MULT";
    symbols["/"] = "DIV";
    symbols["="] = "ASSIGN";
    symbols["("] = "LPARENT";
    symbols[")"] = "RPARENT";
    symbols["{"] = "LBRACE";
    symbols["}"] = "RBRACE";
    symbols[";"] = "SEMICN";
    symbols[","] = "COMMA";
}

bool readNextTokenFromFile() {
    char c;
    
    while (inFile.get(c)) {
        if (!isspace(c)) {
            inFile.putback(c);
            break;
        }
    }
    
    if (!inFile.get(c)) {
        return false;
    }
    
    if (isalpha(c) || c == '_') {
        string id;
        id += c;
        while (inFile.get(c)) {
            if (isalnum(c) || c == '_') {
                id += c;
            } else {
                inFile.putback(c);
                break;
            }
        }
        
        string lowerId = id;
        for (char &ch : lowerId) {
            ch = tolower(ch);
        }
        
        if (keywords.find(lowerId) != keywords.end()) {
            currentToken = keywords[lowerId];
            currentValue = id;
        } else {
            currentToken = "IDENFR";
            currentValue = id;
        }
        return true;
    }
    
    if (isdigit(c)) {
        currentToken = "INTCON";
        currentValue = "";
        currentValue += c;
        while (inFile.get(c)) {
            if (isdigit(c)) {
                currentValue += c;
            } else {
                inFile.putback(c);
                break;
            }
        }
        return true;
    }
    
    if (c == '-') {
        currentToken = "MINU";
        currentValue = "-";
        return true;
    }
    
    if (c == '\'') {
        currentToken = "CHARCON";
        currentValue = "";
        while (inFile.get(c)) {
            if (c == '\'') {
                break;
            }
            currentValue += c;
        }
        return true;
    }
    
    if (c == '"') {
        currentToken = "STRCON";
        currentValue = "";
        while (inFile.get(c)) {
            if (c == '"') {
                break;
            }
            currentValue += c;
        }
        return true;
    }
    
    string symbol(1, c);
    if (symbols.find(symbol) != symbols.end()) {
        currentToken = symbols[symbol];
        currentValue = symbol;
        return true;
    }
    
    currentToken = "UNKNOWN";
    currentValue = symbol;
    return true;
}

bool getNextToken() {
    bufferIndex++;
    
    if (bufferIndex < tokenBuffer.size()) {
        currentToken = tokenBuffer[bufferIndex].first;
        currentValue = tokenBuffer[bufferIndex].second;
        return true;
    } else {
        if (readNextTokenFromFile()) {
            tokenBuffer.push_back({currentToken, currentValue});
            return true;
        }
        return false;
    }
}

void backtrackToken() {
    if (bufferIndex >= 0) {
        bufferIndex--;
    }
}

void outputToken() {
    if (enableOutput) {
        outFile << currentToken << " " << currentValue << endl;
        cout << currentToken << " " << currentValue << endl;
    }
}

void printSyntax(const string &component) {
    if (enableOutput) {
        outFile << component << endl;
        cout << component << endl;
    }
}

void Program();
void ConstDecl();
void VarDecl();
void FuncDef();
void MainFunc();
void ConstDef();
void VarDef();
void ParamList();
void FuncHead();
void CompoundStmt();
void StmtList();
void Stmt();
void Expression();
void Term();
void Factor();
void AssignmentStmt();
void ReturnStmt();
void WriteStmt();
void ArgumentList();

void Program() {
    ConstDecl();
    VarDecl();
    
    while (true) {
        int saveIndex = bufferIndex;
        string saveToken = currentToken;
        string saveValue = currentValue;
        
        if ((currentToken == "INTTK" || currentToken == "VOIDTK") && 
            getNextToken() && currentToken == "IDENFR" && 
            getNextToken() && currentToken == "LPARENT") {
            
            bufferIndex = saveIndex;
            currentToken = saveToken;
            currentValue = saveValue;
            
            FuncDef();
        } else {
            bufferIndex = saveIndex;
            currentToken = saveToken;
            currentValue = saveValue;
            break;
        }
    }
    
    MainFunc();
    printSyntax("<程序>");
}

void ConstDecl() {
    while (currentToken == "CONSTTK") {
        outputToken();
        getNextToken();
        
        outputToken();
        getNextToken();
        
        ConstDef();
        while (currentToken == "COMMA") {
            outputToken();
            getNextToken();
            ConstDef();
        }
        
        if (currentToken == "SEMICN") {
            outputToken();
            getNextToken();
        }
        printSyntax("<常量说明>");
    }
}

void VarDecl() {
    while (currentToken == "INTTK" || currentToken == "CHARTK") {
        int saveIndex = bufferIndex;
        string saveToken = currentToken;
        string saveValue = currentValue;
        
        if (getNextToken() && currentToken == "IDENFR" && 
            getNextToken() && currentToken == "LPARENT") {
            bufferIndex = saveIndex;
            currentToken = saveToken;
            currentValue = saveValue;
            return;
        }
        
        bufferIndex = saveIndex;
        currentToken = saveToken;
        currentValue = saveValue;
        
        outputToken();
        getNextToken();
        
        VarDef();
        while (currentToken == "COMMA") {
            outputToken();
            getNextToken();
            VarDef();
        }
        
        if (currentToken == "SEMICN") {
            outputToken();
            getNextToken();
        }
        printSyntax("<变量说明>");
    }
}

void ConstDef() {
    outputToken();
    getNextToken();
    
    if (currentToken == "ASSIGN") {
        outputToken();
        getNextToken();
        
        if (currentToken == "INTCON") {
            outputToken();
            printSyntax("<无符号整数>");
            printSyntax("<整数>");
            getNextToken();
        } else if (currentToken == "MINU") {
            outputToken();
            getNextToken();
            if (currentToken == "INTCON") {
                outputToken();
                printSyntax("<无符号整数>");
                getNextToken();
            }
            printSyntax("<整数>");
        } else if (currentToken == "CHARCON") {
            outputToken();
            getNextToken();
        }
    }
    printSyntax("<常量定义>");
}

void VarDef() {
    outputToken();
    printSyntax("<变量定义无初始化>");
    printSyntax("<变量定义>");
    getNextToken();
    
    if (currentToken == "ASSIGN") {
        outputToken();
        getNextToken();
        Expression();
    }
}

void FuncDef() {
    if (currentToken == "INTTK") {
        outputToken();
        getNextToken();
        FuncHead();
        CompoundStmt();
        printSyntax("<有返回值函数定义>");
    } else if (currentToken == "VOIDTK") {
        outputToken();
        getNextToken();
        if (currentToken == "MAINTK") {
            backtrackToken();
            backtrackToken();
            getNextToken();
            return;
        }
        FuncHead();
        CompoundStmt();
        printSyntax("<无返回值函数定义>");
    }
}

void FuncHead() {
    outputToken();
    printSyntax("<声明头部>");
    getNextToken();
    
    if (currentToken == "LPARENT") {
        outputToken();
        getNextToken();
        
        if (currentToken != "RPARENT") {
            ParamList();
        }
        
        if (currentToken == "RPARENT") {
            outputToken();
            getNextToken();
        }
    }
}

void ParamList() {
    while (true) {
        outputToken();
        getNextToken();
        outputToken();
        getNextToken();
        
        if (currentToken != "COMMA") {
            break;
        }
        
        outputToken();
        getNextToken();
    }
    printSyntax("<参数表>");
}

void MainFunc() {
    if (currentToken == "VOIDTK") {
        outputToken();
        getNextToken();
        
        if (currentToken == "MAINTK") {
            outputToken();
            getNextToken();
            
            if (currentToken == "LPARENT") {
                outputToken();
                getNextToken();
                
                if (currentToken == "RPARENT") {
                    outputToken();
                    getNextToken();
                    CompoundStmt();
                }
            }
        }
    }
    printSyntax("<主函数>");
}

void CompoundStmt() {
    outputToken();
    getNextToken();
    
    ConstDecl();
    VarDecl();
    
    StmtList();
    
    printSyntax("<复合语句>");
    if (currentToken == "RBRACE") {
        outputToken();
        getNextToken();
    }
}

void StmtList() {
    bool hasStmt = false;
    while (currentToken != "RBRACE") {
        hasStmt = true;
        Stmt();
    }
    if (hasStmt) {
        printSyntax("<语句列>");
    }
}

void Stmt() {
    if (currentToken == "IDENFR") {
        int saveIndex = bufferIndex;
        string saveToken = currentToken;
        string saveValue = currentValue;
        bool isAssign = false;
        
        if (getNextToken() && currentToken == "ASSIGN") {
            isAssign = true;
        }
        
        bufferIndex = saveIndex;
        currentToken = saveToken;
        currentValue = saveValue;
        
        if (isAssign) {
            AssignmentStmt();
        } else {
            Factor();
            if (currentToken == "SEMICN") {
                outputToken();
                getNextToken();
            }
        }
    } else if (currentToken == "RETURNTK") {
        ReturnStmt();
    } else if (currentToken == "PRINTFTK") {
        WriteStmt();
    } else if (currentToken == "LBRACE") {
        CompoundStmt();
    } else {
        Expression();
        if (currentToken == "SEMICN") {
            outputToken();
            getNextToken();
        }
    }
    printSyntax("<语句>");
}

void AssignmentStmt() {
    outputToken();
    getNextToken();
    outputToken();
    getNextToken();
    Expression();
    printSyntax("<赋值语句>");
    if (currentToken == "SEMICN") {
        outputToken();
        getNextToken();
    }
}

void ReturnStmt() {
    outputToken();
    getNextToken();
    
    if (currentToken == "LPARENT") {
        outputToken();
        getNextToken();
        Expression();
        if (currentToken == "RPARENT") {
            outputToken();
            getNextToken();
        }
    } else {
        Expression();
    }
    
    printSyntax("<返回语句>");
    if (currentToken == "SEMICN") {
        outputToken();
        getNextToken();
    }
}

void WriteStmt() {
    outputToken();
    getNextToken();
    
    if (currentToken == "LPARENT") {
        outputToken();
        getNextToken();
        
        if (currentToken == "STRCON") {
            outputToken();
            printSyntax("<字符串>");
            getNextToken();
        } else {
            Expression();
        }
        
        if (currentToken == "RPARENT") {
            outputToken();
            getNextToken();
        }
    }
    
    printSyntax("<写语句>");
    if (currentToken == "SEMICN") {
        outputToken();
        getNextToken();
    }
}

void Expression() {
    Term();
    while (currentToken == "PLUS" || currentToken == "MINU") {
        outputToken();
        getNextToken();
        Term();
    }
    printSyntax("<表达式>");
}

void Term() {
    Factor();
    while (currentToken == "MULT" || currentToken == "DIV") {
        outputToken();
        getNextToken();
        Factor();
    }
    printSyntax("<项>");
}

void Factor() {
    if (currentToken == "IDENFR") {
        outputToken();
        getNextToken();
        
        if (currentToken == "LPARENT") {
            outputToken();
            getNextToken();
            
            if (currentToken != "RPARENT") {
                ArgumentList();
            }
            
            if (currentToken == "RPARENT") {
                outputToken();
                getNextToken();
                printSyntax("<有返回值函数调用语句>");
            }
        }
    } else if (currentToken == "INTCON") {
        outputToken();
        printSyntax("<无符号整数>");
        printSyntax("<整数>");
        getNextToken();
    } else if (currentToken == "MINU") {
        outputToken();
        getNextToken();
        if (currentToken == "INTCON") {
            outputToken();
            printSyntax("<无符号整数>");
            getNextToken();
        }
        printSyntax("<整数>");
    } else if (currentToken == "LPARENT") {
        outputToken();
        getNextToken();
        Expression();
        if (currentToken == "RPARENT") {
            outputToken();
            getNextToken();
        }
    }
    printSyntax("<因子>");
}

void ArgumentList() {
    Expression();
    while (currentToken == "COMMA") {
        outputToken();
        getNextToken();
        Expression();
    }
    printSyntax("<值参数表>");
}

int main() {
    initHashTables();
    cout << "哈希表初始化完成" << endl;
    
    inFile.open("testfile.txt");
    if (!inFile.is_open()) {
        cout << "无法打开testfile.txt" << endl;
        return 1;
    }
    
    outFile.open("output.txt");
    if (!outFile.is_open()) {
        cout << "无法打开output.txt" << endl;
        return 1;
    }
    
    cout << "从testfile.txt读取的内容：" << endl;
    string line;
    string fileContent;
    while (getline(inFile, line)) {
        fileContent += line + "\n";
    }
    cout << fileContent << endl;
    
    inFile.clear();
    inFile.seekg(0);
    
    getNextToken();
    
    Program();
    
    inFile.close();
    outFile.close();
    
    cout << "已成功将语法分析结果写入output.txt文件" << endl;
    
    return 0;
}
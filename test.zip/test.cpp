#include <iostream>
#include <fstream>
#include <unordered_map>
#include <string>
#include <cctype>
#include <vector>
#include <memory>
using namespace std;

string currentToken;
string currentValue;
ifstream inFile;
ofstream outFile;
bool enableOutput = true;
vector<pair<string, string>> tokenBuffer;
int bufferIndex = -1;

unordered_map<string, string> keywords;
unordered_map<string, string> symbols;

// 语法树节点类型枚举
enum class NodeType {
    PROGRAM,             // 程序
    CONST_DECL,          // 常量说明
    VAR_DECL,            // 变量说明
    CONST_DEF,           // 常量定义
    VAR_DEF,             // 变量定义
    FUNC_DEF,            // 函数定义
    MAIN_FUNC,           // 主函数
    FUNC_HEAD,           // 声明头部
    PARAM_LIST,          // 参数表
    COMPOUND_STMT,       // 复合语句
    STMT_LIST,           // 语句列
    STMT,                // 语句
    ASSIGNMENT_STMT,     // 赋值语句
    RETURN_STMT,         // 返回语句
    WRITE_STMT,          // 写语句
    EXPRESSION,          // 表达式
    TERM,                // 项
    FACTOR,              // 因子
    ARGUMENT_LIST,       // 值参数表
    INT_CONST,           // 整数
    UNSIGNED_INT,        // 无符号整数
    STRING_CONST,        // 字符串
    FUNCTION_CALL,       // 函数调用
    TOKEN_NODE           // 终结符节点
};

// 语法树节点类
class SyntaxTreeNode {
public:
    NodeType type;
    string value;
    vector<shared_ptr<SyntaxTreeNode>> children;
    
    SyntaxTreeNode(NodeType type, const string& value = "") : type(type), value(value) {}
    
    void addChild(shared_ptr<SyntaxTreeNode> child) {
        if (child) {
            children.push_back(child);
        }
    }
    
    // 打印树结构（用于调试）
    void printTree(int depth = 0) {
        string indent(depth * 2, ' ');
        cout << indent << "[" << getNodeTypeName(type) << "]";
        if (!value.empty()) {
            cout << " " << value;
        }
        cout << endl;
        
        for (auto& child : children) {
            child->printTree(depth + 1);
        }
    }
    
private:
    string getNodeTypeName(NodeType type) {
        switch (type) {
            case NodeType::PROGRAM: return "程序";
            case NodeType::CONST_DECL: return "常量说明";
            case NodeType::VAR_DECL: return "变量说明";
            case NodeType::CONST_DEF: return "常量定义";
            case NodeType::VAR_DEF: return "变量定义";
            case NodeType::FUNC_DEF: return "函数定义";
            case NodeType::MAIN_FUNC: return "主函数";
            case NodeType::FUNC_HEAD: return "声明头部";
            case NodeType::PARAM_LIST: return "参数表";
            case NodeType::COMPOUND_STMT: return "复合语句";
            case NodeType::STMT_LIST: return "语句列";
            case NodeType::STMT: return "语句";
            case NodeType::ASSIGNMENT_STMT: return "赋值语句";
            case NodeType::RETURN_STMT: return "返回语句";
            case NodeType::WRITE_STMT: return "写语句";
            case NodeType::EXPRESSION: return "表达式";
            case NodeType::TERM: return "项";
            case NodeType::FACTOR: return "因子";
            case NodeType::ARGUMENT_LIST: return "值参数表";
            case NodeType::INT_CONST: return "整数";
            case NodeType::UNSIGNED_INT: return "无符号整数";
            case NodeType::STRING_CONST: return "字符串";
            case NodeType::FUNCTION_CALL: return "函数调用";
            case NodeType::TOKEN_NODE: return "终结符";
            default: return "未知";
        }
    }
};

void initHashTables() {
    keywords["const"] = "CONSTTK";
    keywords["int"] = "INTTK";
    keywords["char"] = "CHARTK";
    keywords["void"] = "VOIDTK";
    keywords["main"] = "MAINTK";
    keywords["if"] = "IFTK";
    keywords["else"] = "ELSETK";
    keywords["while"] = "WHILETK";
    keywords["break"] = "BREAKTK";
    keywords["continue"] = "CONTINUETK";
    keywords["return"] = "RETURNTK";
    keywords["printf"] = "PRINTFTK";
    
    symbols["+"] = "PLUS";
    symbols["-"] = "MINU";
    symbols["*"] = "MULT";
    symbols["/"] = "DIV";
    symbols["="] = "ASSIGN";
    symbols["("] = "LPARENT";
    symbols[")"] = "RPARENT";
    symbols["{"] = "LBRACE";
    symbols["}"] = "RBRACE";
    symbols[";"] = "SEMICN";
    symbols[","] = "COMMA";
}

bool readNextTokenFromFile() {
    char c;
    
    while (inFile.get(c)) {
        if (!isspace(c)) {
            inFile.putback(c);
            break;
        }
    }
    
    if (!inFile.get(c)) {
        return false;
    }
    
    if (isalpha(c) || c == '_') {
        string id;
        id += c;
        while (inFile.get(c)) {
            if (isalnum(c) || c == '_') {
                id += c;
            } else {
                inFile.putback(c);
                break;
            }
        }
        
        string lowerId = id;
        for (char &ch : lowerId) {
            ch = tolower(ch);
        }
        
        if (keywords.find(lowerId) != keywords.end()) {
            currentToken = keywords[lowerId];
            currentValue = id;
        } else {
            currentToken = "IDENFR";
            currentValue = id;
        }
        return true;
    }
    
    if (isdigit(c)) {
        currentToken = "INTCON";
        currentValue = "";
        currentValue += c;
        while (inFile.get(c)) {
            if (isdigit(c)) {
                currentValue += c;
            } else {
                inFile.putback(c);
                break;
            }
        }
        return true;
    }
    
    if (c == '-') {
        currentToken = "MINU";
        currentValue = "-";
        return true;
    }
    
    if (c == '\'') {
        currentToken = "CHARCON";
        currentValue = "";
        while (inFile.get(c)) {
            if (c == '\'') {
                break;
            }
            currentValue += c;
        }
        return true;
    }
    
    if (c == '"') {
        currentToken = "STRCON";
        currentValue = "";
        while (inFile.get(c)) {
            if (c == '"') {
                break;
            }
            currentValue += c;
        }
        return true;
    }
    
    string symbol(1, c);
    if (symbols.find(symbol) != symbols.end()) {
        currentToken = symbols[symbol];
        currentValue = symbol;
        return true;
    }
    
    currentToken = "UNKNOWN";
    currentValue = symbol;
    return true;
}

bool getNextToken() {
    bufferIndex++;
    
    if (bufferIndex < tokenBuffer.size()) {
        currentToken = tokenBuffer[bufferIndex].first;
        currentValue = tokenBuffer[bufferIndex].second;
        return true;
    } else {
        if (readNextTokenFromFile()) {
            tokenBuffer.push_back({currentToken, currentValue});
            return true;
        }
        return false;
    }
}

void backtrackToken() {
    if (bufferIndex >= 0) {
        bufferIndex--;
    }
}

void outputToken() {
    if (enableOutput) {
        outFile << currentToken << " " << currentValue << endl;
        cout << currentToken << " " << currentValue << endl;
    }
}

void printSyntax(const string &component) {
    if (enableOutput) {
        outFile << component << endl;
        cout << component << endl;
    }
}

// 创建终结符节点
shared_ptr<SyntaxTreeNode> createTokenNode() {
    return make_shared<SyntaxTreeNode>(NodeType::TOKEN_NODE, currentToken + " " + currentValue);
}

shared_ptr<SyntaxTreeNode> Program();
shared_ptr<SyntaxTreeNode> ConstDecl();
shared_ptr<SyntaxTreeNode> VarDecl();
shared_ptr<SyntaxTreeNode> FuncDef();
shared_ptr<SyntaxTreeNode> MainFunc();
shared_ptr<SyntaxTreeNode> ConstDef();
shared_ptr<SyntaxTreeNode> VarDef();
shared_ptr<SyntaxTreeNode> ParamList();
shared_ptr<SyntaxTreeNode> FuncHead();
shared_ptr<SyntaxTreeNode> CompoundStmt();
shared_ptr<SyntaxTreeNode> StmtList();
shared_ptr<SyntaxTreeNode> Stmt();
shared_ptr<SyntaxTreeNode> Expression();
shared_ptr<SyntaxTreeNode> Term();
shared_ptr<SyntaxTreeNode> Factor();
shared_ptr<SyntaxTreeNode> AssignmentStmt();
shared_ptr<SyntaxTreeNode> ReturnStmt();
shared_ptr<SyntaxTreeNode> WriteStmt();
shared_ptr<SyntaxTreeNode> ArgumentList();

shared_ptr<SyntaxTreeNode> Program() {
    auto node = make_shared<SyntaxTreeNode>(NodeType::PROGRAM);
    
    auto constDeclNode = ConstDecl();
    if (constDeclNode) node->addChild(constDeclNode);
    
    auto varDeclNode = VarDecl();
    if (varDeclNode) node->addChild(varDeclNode);
    
    while (true) {
        int saveIndex = bufferIndex;
        string saveToken = currentToken;
        string saveValue = currentValue;
        
        if ((currentToken == "INTTK" || currentToken == "VOIDTK") && 
            getNextToken() && currentToken == "IDENFR" && 
            getNextToken() && currentToken == "LPARENT") {
            
            bufferIndex = saveIndex;
            currentToken = saveToken;
            currentValue = saveValue;
            
            auto funcDefNode = FuncDef();
            if (funcDefNode) node->addChild(funcDefNode);
        } else {
            bufferIndex = saveIndex;
            currentToken = saveToken;
            currentValue = saveValue;
            break;
        }
    }
    
    auto mainFuncNode = MainFunc();
    if (mainFuncNode) node->addChild(mainFuncNode);
    
    printSyntax("<程序>");
    return node;
}

shared_ptr<SyntaxTreeNode> ConstDecl() {
    bool hasDecl = false;
    auto node = make_shared<SyntaxTreeNode>(NodeType::CONST_DECL);
    
    while (currentToken == "CONSTTK") {
        hasDecl = true;
        auto constDeclNode = make_shared<SyntaxTreeNode>(NodeType::CONST_DECL);
        
        outputToken();
        constDeclNode->addChild(createTokenNode());
        getNextToken();
        
        outputToken();
        constDeclNode->addChild(createTokenNode());
        getNextToken();
        
        auto constDefNode = ConstDef();
        if (constDefNode) constDeclNode->addChild(constDefNode);
        
        while (currentToken == "COMMA") {
            outputToken();
            constDeclNode->addChild(createTokenNode());
            getNextToken();
            auto nextConstDefNode = ConstDef();
            if (nextConstDefNode) constDeclNode->addChild(nextConstDefNode);
        }
        
        if (currentToken == "SEMICN") {
            outputToken();
            constDeclNode->addChild(createTokenNode());
            getNextToken();
        }
        
        printSyntax("<常量说明>");
        node->addChild(constDeclNode);
    }
    
    return hasDecl ? node : nullptr;
}

shared_ptr<SyntaxTreeNode> VarDecl() {
    bool hasDecl = false;
    auto node = make_shared<SyntaxTreeNode>(NodeType::VAR_DECL);
    
    while (currentToken == "INTTK" || currentToken == "CHARTK") {
        int saveIndex = bufferIndex;
        string saveToken = currentToken;
        string saveValue = currentValue;
        
        if (getNextToken() && currentToken == "IDENFR" && 
            getNextToken() && currentToken == "LPARENT") {
            bufferIndex = saveIndex;
            currentToken = saveToken;
            currentValue = saveValue;
            break;
        }
        
        bufferIndex = saveIndex;
        currentToken = saveToken;
        currentValue = saveValue;
        
        hasDecl = true;
        auto varDeclNode = make_shared<SyntaxTreeNode>(NodeType::VAR_DECL);
        
        outputToken();
        varDeclNode->addChild(createTokenNode());
        getNextToken();
        
        auto varDefNode = VarDef();
        if (varDefNode) varDeclNode->addChild(varDefNode);
        
        while (currentToken == "COMMA") {
            outputToken();
            varDeclNode->addChild(createTokenNode());
            getNextToken();
            auto nextVarDefNode = VarDef();
            if (nextVarDefNode) varDeclNode->addChild(nextVarDefNode);
        }
        
        if (currentToken == "SEMICN") {
            outputToken();
            varDeclNode->addChild(createTokenNode());
            getNextToken();
        }
        
        printSyntax("<变量说明>");
        node->addChild(varDeclNode);
    }
    
    return hasDecl ? node : nullptr;
}

shared_ptr<SyntaxTreeNode> ConstDef() {
    auto node = make_shared<SyntaxTreeNode>(NodeType::CONST_DEF);
    
    outputToken();
    node->addChild(createTokenNode());
    getNextToken();
    
    if (currentToken == "ASSIGN") {
        outputToken();
        node->addChild(createTokenNode());
        getNextToken();
        
        if (currentToken == "INTCON") {
            outputToken();
            node->addChild(createTokenNode());
            
            auto unsignedIntNode = make_shared<SyntaxTreeNode>(NodeType::UNSIGNED_INT);
            node->addChild(unsignedIntNode);
            printSyntax("<无符号整数>");
            
            auto intNode = make_shared<SyntaxTreeNode>(NodeType::INT_CONST);
            node->addChild(intNode);
            printSyntax("<整数>");
            
            getNextToken();
        } else if (currentToken == "MINU") {
            outputToken();
            node->addChild(createTokenNode());
            getNextToken();
            
            if (currentToken == "INTCON") {
                outputToken();
                node->addChild(createTokenNode());
                
                auto unsignedIntNode = make_shared<SyntaxTreeNode>(NodeType::UNSIGNED_INT);
                node->addChild(unsignedIntNode);
                printSyntax("<无符号整数>");
                
                getNextToken();
            }
            
            auto intNode = make_shared<SyntaxTreeNode>(NodeType::INT_CONST);
            node->addChild(intNode);
            printSyntax("<整数>");
        } else if (currentToken == "CHARCON") {
            outputToken();
            node->addChild(createTokenNode());
            getNextToken();
        }
    }
    
    printSyntax("<常量定义>");
    return node;
}

shared_ptr<SyntaxTreeNode> VarDef() {
    auto node = make_shared<SyntaxTreeNode>(NodeType::VAR_DEF);
    
    outputToken();
    node->addChild(createTokenNode());
    
    auto varDefNoInitNode = make_shared<SyntaxTreeNode>(NodeType::VAR_DEF, "无初始化");
    node->addChild(varDefNoInitNode);
    printSyntax("<变量定义无初始化>");
    
    printSyntax("<变量定义>");
    getNextToken();
    
    if (currentToken == "ASSIGN") {
        outputToken();
        node->addChild(createTokenNode());
        getNextToken();
        
        auto exprNode = Expression();
        if (exprNode) node->addChild(exprNode);
    }
    
    return node;
}

shared_ptr<SyntaxTreeNode> FuncDef() {
    auto node = make_shared<SyntaxTreeNode>(NodeType::FUNC_DEF);
    bool isIntFunc = false;
    
    if (currentToken == "INTTK") {
        isIntFunc = true;
        outputToken();
        node->addChild(createTokenNode());
        getNextToken();
        
        auto funcHeadNode = FuncHead();
        if (funcHeadNode) node->addChild(funcHeadNode);
        
        auto compoundStmtNode = CompoundStmt();
        if (compoundStmtNode) node->addChild(compoundStmtNode);
        
        printSyntax("<有返回值函数定义>");
    } else if (currentToken == "VOIDTK") {
        outputToken();
        node->addChild(createTokenNode());
        getNextToken();
        
        if (currentToken == "MAINTK") {
            backtrackToken();
            backtrackToken();
            getNextToken();
            return nullptr;
        }
        
        auto funcHeadNode = FuncHead();
        if (funcHeadNode) node->addChild(funcHeadNode);
        
        auto compoundStmtNode = CompoundStmt();
        if (compoundStmtNode) node->addChild(compoundStmtNode);
        
        printSyntax("<无返回值函数定义>");
    }
    
    return node;
}

shared_ptr<SyntaxTreeNode> FuncHead() {
    auto node = make_shared<SyntaxTreeNode>(NodeType::FUNC_HEAD);
    
    outputToken();
    node->addChild(createTokenNode());
    
    printSyntax("<声明头部>");
    getNextToken();
    
    if (currentToken == "LPARENT") {
        outputToken();
        node->addChild(createTokenNode());
        getNextToken();
        
        if (currentToken != "RPARENT") {
            auto paramListNode = ParamList();
            if (paramListNode) node->addChild(paramListNode);
        }
        
        if (currentToken == "RPARENT") {
            outputToken();
            node->addChild(createTokenNode());
            getNextToken();
        }
    }
    
    return node;
}

shared_ptr<SyntaxTreeNode> ParamList() {
    auto node = make_shared<SyntaxTreeNode>(NodeType::PARAM_LIST);
    
    while (true) {
        outputToken();
        node->addChild(createTokenNode());
        getNextToken();
        
        outputToken();
        node->addChild(createTokenNode());
        getNextToken();
        
        if (currentToken != "COMMA") {
            break;
        }
        
        outputToken();
        node->addChild(createTokenNode());
        getNextToken();
    }
    
    printSyntax("<参数表>");
    return node;
}

shared_ptr<SyntaxTreeNode> MainFunc() {
    auto node = make_shared<SyntaxTreeNode>(NodeType::MAIN_FUNC);
    
    if (currentToken == "VOIDTK") {
        outputToken();
        node->addChild(createTokenNode());
        getNextToken();
        
        if (currentToken == "MAINTK") {
            outputToken();
            node->addChild(createTokenNode());
            getNextToken();
            
            if (currentToken == "LPARENT") {
                outputToken();
                node->addChild(createTokenNode());
                getNextToken();
                
                if (currentToken == "RPARENT") {
                    outputToken();
                    node->addChild(createTokenNode());
                    getNextToken();
                    
                    auto compoundStmtNode = CompoundStmt();
                    if (compoundStmtNode) node->addChild(compoundStmtNode);
                }
            }
        }
    }
    
    printSyntax("<主函数>");
    return node;
}

shared_ptr<SyntaxTreeNode> CompoundStmt() {
    auto node = make_shared<SyntaxTreeNode>(NodeType::COMPOUND_STMT);
    
    outputToken();
    node->addChild(createTokenNode());
    getNextToken();
    
    auto constDeclNode = ConstDecl();
    if (constDeclNode) node->addChild(constDeclNode);
    
    auto varDeclNode = VarDecl();
    if (varDeclNode) node->addChild(varDeclNode);
    
    auto stmtListNode = StmtList();
    if (stmtListNode) node->addChild(stmtListNode);
    
    printSyntax("<复合语句>");
    
    if (currentToken == "RBRACE") {
        outputToken();
        node->addChild(createTokenNode());
        getNextToken();
    }
    
    return node;
}

shared_ptr<SyntaxTreeNode> StmtList() {
    bool hasStmt = false;
    auto node = make_shared<SyntaxTreeNode>(NodeType::STMT_LIST);
    
    while (currentToken != "RBRACE") {
        hasStmt = true;
        auto stmtNode = Stmt();
        if (stmtNode) node->addChild(stmtNode);
    }
    
    if (hasStmt) {
        printSyntax("<语句列>");
        return node;
    }
    
    return nullptr;
}

shared_ptr<SyntaxTreeNode> Stmt() {
    auto node = make_shared<SyntaxTreeNode>(NodeType::STMT);
    
    if (currentToken == "IDENFR") {
        int saveIndex = bufferIndex;
        string saveToken = currentToken;
        string saveValue = currentValue;
        bool isAssign = false;
        
        if (getNextToken() && currentToken == "ASSIGN") {
            isAssign = true;
        }
        
        bufferIndex = saveIndex;
        currentToken = saveToken;
        currentValue = saveValue;
        
        if (isAssign) {
            auto assignStmtNode = AssignmentStmt();
            if (assignStmtNode) node->addChild(assignStmtNode);
        } else {
            auto factorNode = Factor();
            if (factorNode) node->addChild(factorNode);
            
            if (currentToken == "SEMICN") {
                outputToken();
                node->addChild(createTokenNode());
                getNextToken();
            }
        }
    } else if (currentToken == "RETURNTK") {
        auto returnStmtNode = ReturnStmt();
        if (returnStmtNode) node->addChild(returnStmtNode);
    } else if (currentToken == "PRINTFTK") {
        auto writeStmtNode = WriteStmt();
        if (writeStmtNode) node->addChild(writeStmtNode);
    } else if (currentToken == "LBRACE") {
        auto compoundStmtNode = CompoundStmt();
        if (compoundStmtNode) node->addChild(compoundStmtNode);
    } else {
        auto exprNode = Expression();
        if (exprNode) node->addChild(exprNode);
        
        if (currentToken == "SEMICN") {
            outputToken();
            node->addChild(createTokenNode());
            getNextToken();
        }
    }
    
    printSyntax("<语句>");
    return node;
}

shared_ptr<SyntaxTreeNode> AssignmentStmt() {
    auto node = make_shared<SyntaxTreeNode>(NodeType::ASSIGNMENT_STMT);
    
    outputToken();
    node->addChild(createTokenNode());
    getNextToken();
    
    outputToken();
    node->addChild(createTokenNode());
    getNextToken();
    
    auto exprNode = Expression();
    if (exprNode) node->addChild(exprNode);
    
    printSyntax("<赋值语句>");
    
    if (currentToken == "SEMICN") {
        outputToken();
        node->addChild(createTokenNode());
        getNextToken();
    }
    
    return node;
}

shared_ptr<SyntaxTreeNode> ReturnStmt() {
    auto node = make_shared<SyntaxTreeNode>(NodeType::RETURN_STMT);
    
    outputToken();
    node->addChild(createTokenNode());
    getNextToken();
    
    if (currentToken == "LPARENT") {
        outputToken();
        node->addChild(createTokenNode());
        getNextToken();
        
        auto exprNode = Expression();
        if (exprNode) node->addChild(exprNode);
        
        if (currentToken == "RPARENT") {
            outputToken();
            node->addChild(createTokenNode());
            getNextToken();
        }
    } else {
        auto exprNode = Expression();
        if (exprNode) node->addChild(exprNode);
    }
    
    printSyntax("<返回语句>");
    
    if (currentToken == "SEMICN") {
        outputToken();
        node->addChild(createTokenNode());
        getNextToken();
    }
    
    return node;
}

shared_ptr<SyntaxTreeNode> WriteStmt() {
    auto node = make_shared<SyntaxTreeNode>(NodeType::WRITE_STMT);
    
    outputToken();
    node->addChild(createTokenNode());
    getNextToken();
    
    if (currentToken == "LPARENT") {
        outputToken();
        node->addChild(createTokenNode());
        getNextToken();
        
        if (currentToken == "STRCON") {
            outputToken();
            node->addChild(createTokenNode());
            
            auto stringNode = make_shared<SyntaxTreeNode>(NodeType::STRING_CONST);
            node->addChild(stringNode);
            printSyntax("<字符串>");
            
            getNextToken();
        } else {
            auto exprNode = Expression();
            if (exprNode) node->addChild(exprNode);
        }
        
        if (currentToken == "RPARENT") {
            outputToken();
            node->addChild(createTokenNode());
            getNextToken();
        }
    }
    
    printSyntax("<写语句>");
    
    if (currentToken == "SEMICN") {
        outputToken();
        node->addChild(createTokenNode());
        getNextToken();
    }
    
    return node;
}

shared_ptr<SyntaxTreeNode> Expression() {
    auto node = make_shared<SyntaxTreeNode>(NodeType::EXPRESSION);
    
    auto termNode = Term();
    if (termNode) node->addChild(termNode);
    
    while (currentToken == "PLUS" || currentToken == "MINU") {
        outputToken();
        node->addChild(createTokenNode());
        getNextToken();
        
        auto nextTermNode = Term();
        if (nextTermNode) node->addChild(nextTermNode);
    }
    
    printSyntax("<表达式>");
    return node;
}

shared_ptr<SyntaxTreeNode> Term() {
    auto node = make_shared<SyntaxTreeNode>(NodeType::TERM);
    
    auto factorNode = Factor();
    if (factorNode) node->addChild(factorNode);
    
    while (currentToken == "MULT" || currentToken == "DIV") {
        outputToken();
        node->addChild(createTokenNode());
        getNextToken();
        
        auto nextFactorNode = Factor();
        if (nextFactorNode) node->addChild(nextFactorNode);
    }
    
    printSyntax("<项>");
    return node;
}

shared_ptr<SyntaxTreeNode> Factor() {
    auto node = make_shared<SyntaxTreeNode>(NodeType::FACTOR);
    
    if (currentToken == "IDENFR") {
        outputToken();
        node->addChild(createTokenNode());
        getNextToken();
        
        if (currentToken == "LPARENT") {
            outputToken();
            node->addChild(createTokenNode());
            getNextToken();
            
            if (currentToken != "RPARENT") {
                auto argListNode = ArgumentList();
                if (argListNode) node->addChild(argListNode);
            }
            
            if (currentToken == "RPARENT") {
                outputToken();
                node->addChild(createTokenNode());
                getNextToken();
                
                auto funcCallNode = make_shared<SyntaxTreeNode>(NodeType::FUNCTION_CALL);
                node->addChild(funcCallNode);
                printSyntax("<有返回值函数调用语句>");
            }
        }
    } else if (currentToken == "INTCON") {
        outputToken();
        node->addChild(createTokenNode());
        
        auto unsignedIntNode = make_shared<SyntaxTreeNode>(NodeType::UNSIGNED_INT);
        node->addChild(unsignedIntNode);
        printSyntax("<无符号整数>");
        
        auto intNode = make_shared<SyntaxTreeNode>(NodeType::INT_CONST);
        node->addChild(intNode);
        printSyntax("<整数>");
        
        getNextToken();
    } else if (currentToken == "MINU") {
        outputToken();
        node->addChild(createTokenNode());
        getNextToken();
        
        if (currentToken == "INTCON") {
            outputToken();
            node->addChild(createTokenNode());
            
            auto unsignedIntNode = make_shared<SyntaxTreeNode>(NodeType::UNSIGNED_INT);
            node->addChild(unsignedIntNode);
            printSyntax("<无符号整数>");
            
            getNextToken();
        }
        
        auto intNode = make_shared<SyntaxTreeNode>(NodeType::INT_CONST);
        node->addChild(intNode);
        printSyntax("<整数>");
    } else if (currentToken == "LPARENT") {
        outputToken();
        node->addChild(createTokenNode());
        getNextToken();
        
        auto exprNode = Expression();
        if (exprNode) node->addChild(exprNode);
        
        if (currentToken == "RPARENT") {
            outputToken();
            node->addChild(createTokenNode());
            getNextToken();
        }
    }
    
    printSyntax("<因子>");
    return node;
}

shared_ptr<SyntaxTreeNode> ArgumentList() {
    auto node = make_shared<SyntaxTreeNode>(NodeType::ARGUMENT_LIST);
    
    auto exprNode = Expression();
    if (exprNode) node->addChild(exprNode);
    
    while (currentToken == "COMMA") {
        outputToken();
        node->addChild(createTokenNode());
        getNextToken();
        
        auto nextExprNode = Expression();
        if (nextExprNode) node->addChild(nextExprNode);
    }
    
    printSyntax("<值参数表>");
    return node;
}

int main() {
    initHashTables();
    cout << "哈希表初始化完成" << endl;
    
    inFile.open("testfile.txt");
    if (!inFile.is_open()) {
        cout << "无法打开testfile.txt" << endl;
        return 1;
    }
    
    outFile.open("output.txt");
    if (!outFile.is_open()) {
        cout << "无法打开output.txt" << endl;
        return 1;
    }
    
    cout << "从testfile.txt读取的内容：" << endl;
    string line;
    string fileContent;
    while (getline(inFile, line)) {
        fileContent += line + "\n";
    }
    cout << fileContent << endl;
    
    inFile.clear();
    inFile.seekg(0);
    
    getNextToken();
    
    // 构建语法分析树
    shared_ptr<SyntaxTreeNode> syntaxTree = Program();
    
    // 打印语法树（可选，用于调试）
    cout << "\n语法分析树结构：" << endl;
    if (syntaxTree) {
        syntaxTree->printTree();
    }
    
    inFile.close();
    outFile.close();
    
    cout << "已成功将语法分析结果写入output.txt文件" << endl;
    cout << "语法分析树构建完成" << endl;
    
    return 0;
}